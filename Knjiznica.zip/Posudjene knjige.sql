USE [knjiznica]
GO

/****** Object:  Table [dbo].[POSUDJENE KNJIGE]    Script Date: 1/19/2024 3:02:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[POSUDJENE KNJIGE](
	[ime i prezime] [ntext] NULL,
	[datum posudbe] [nchar](10) NULL,
	[naslov knjige] [ntext] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

