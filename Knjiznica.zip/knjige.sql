USE [knjiznica]
GO

/****** Object:  Table [dbo].[KNJIGE]    Script Date: 1/19/2024 3:02:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[KNJIGE](
	[naslov knjige] [text] NULL,
	[ime i prezime pisca] [ntext] NULL,
	[godina izdanja] [nchar](10) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

